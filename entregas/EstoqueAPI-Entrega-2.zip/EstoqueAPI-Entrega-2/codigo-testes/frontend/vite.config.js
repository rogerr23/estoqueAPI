import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    host: '127.0.0.1',
    port: 5173,
    strictPort: true,
    proxy: {
      '/api': process.env.ESTOQUE_API_PROXY_TARGET || 'http://127.0.0.1:8080',
      '/swagger-ui': process.env.ESTOQUE_API_PROXY_TARGET || 'http://127.0.0.1:8080',
      '/v3/api-docs': process.env.ESTOQUE_API_PROXY_TARGET || 'http://127.0.0.1:8080',
    },
  },
})
